﻿using Negocios;
using ObjetosTransferencia;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SysBlockchain
{
    public partial class frmAvaliaJuridico : Form
    {
        frmAnalisarTransacoes frm;
        String cliente; String descricao; String valor;
        int codigo;
        public frmAvaliaJuridico(frmAnalisarTransacoes frm, String cliente, String descricao, String valor, int codigo)
        {
            InitializeComponent();
            rdAprovado.Checked = true;
            this.frm = frm;
            this.cliente = cliente;
            this.descricao = descricao;
            this.valor = valor;
            this.codigo = codigo;
            txtCliente.Text = cliente;
            txtDescricao.Text = descricao;
            txtValor.Text = "R$ " + valor;
        }

        private void frmAvaliaJuridico_FormClosed(object sender, FormClosedEventArgs e)
        {
            frm.geraTabelaOperacaoJuridica();
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            const string message =
       "Tem certeza deste procedimento?";
            const string caption = "Confirmação";
            var result = MessageBox.Show(message, caption,
                                         MessageBoxButtons.YesNo,
                                         MessageBoxIcon.Question);

            // If the no button was pressed ...
            if (result == DialogResult.No)
            {
                // cancel the closure of the form.
                return;
            }
            else
            {
                TransacaoJuridica transacaoJuridica = new TransacaoJuridica();
                transacaoJuridica.codigoTransacaoJuridica = codigo;
                if (rdAprovado.Checked)
                {
                    transacaoJuridica.aprovado = 'S';
                }
                else
                {
                    transacaoJuridica.aprovado = 'N';
                }
                TransacaoJuridicaNegocios transacaoJuridicaNegocios = new TransacaoJuridicaNegocios();
                transacaoJuridicaNegocios.avalia(transacaoJuridica);
                this.Close();
            }
            }
    }
}
