﻿namespace SysBlockchain
{
    partial class frmPrincipal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.cadastrosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.funcionáriosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.clienteJuridicoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.clienteFisicoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.atendimentoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.agendarPessoaFisicaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.protocoloToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.abrirProtocoloToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.transaçõesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.abrirTransaçõesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.avaliarTransaçõesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.relatóriosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.funcionáriosCadastradosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.clientesFisicosCadastradosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.clientesJuridicosCadastradosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.protocolosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.agendamentoDeAtendimentoDePessoasFisicasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.agendamentoFuturoDeAtendimentoDePessoasFisicasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.transaçõesDeClientesFisicasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.transaçãoDeClientesJuridicasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.transaçõesFisicasAprovadasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.transaçõesJuridicasAprovadasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.transaçõesFisicasReprovadasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.transaçõesJuridicasReprovadasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sobreOSistemaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.equipeDeDesenvolvimentoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.btnFinalizarVenda = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.tblRelatorio = new System.Windows.Forms.DataGridView();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tblRelatorio)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cadastrosToolStripMenuItem,
            this.atendimentoToolStripMenuItem,
            this.protocoloToolStripMenuItem,
            this.transaçõesToolStripMenuItem,
            this.relatóriosToolStripMenuItem,
            this.sobreOSistemaToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1067, 28);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // cadastrosToolStripMenuItem
            // 
            this.cadastrosToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.funcionáriosToolStripMenuItem,
            this.clienteJuridicoToolStripMenuItem,
            this.clienteFisicoToolStripMenuItem});
            this.cadastrosToolStripMenuItem.Name = "cadastrosToolStripMenuItem";
            this.cadastrosToolStripMenuItem.Size = new System.Drawing.Size(88, 24);
            this.cadastrosToolStripMenuItem.Text = "Cadastros";
            // 
            // funcionáriosToolStripMenuItem
            // 
            this.funcionáriosToolStripMenuItem.Name = "funcionáriosToolStripMenuItem";
            this.funcionáriosToolStripMenuItem.Size = new System.Drawing.Size(193, 26);
            this.funcionáriosToolStripMenuItem.Text = "Funcionários";
            this.funcionáriosToolStripMenuItem.Click += new System.EventHandler(this.funcionáriosToolStripMenuItem_Click);
            // 
            // clienteJuridicoToolStripMenuItem
            // 
            this.clienteJuridicoToolStripMenuItem.Name = "clienteJuridicoToolStripMenuItem";
            this.clienteJuridicoToolStripMenuItem.Size = new System.Drawing.Size(193, 26);
            this.clienteJuridicoToolStripMenuItem.Text = "Cliente Juridico";
            this.clienteJuridicoToolStripMenuItem.Click += new System.EventHandler(this.clienteJuridicoToolStripMenuItem_Click);
            // 
            // clienteFisicoToolStripMenuItem
            // 
            this.clienteFisicoToolStripMenuItem.Name = "clienteFisicoToolStripMenuItem";
            this.clienteFisicoToolStripMenuItem.Size = new System.Drawing.Size(193, 26);
            this.clienteFisicoToolStripMenuItem.Text = "Cliente Fisico";
            this.clienteFisicoToolStripMenuItem.Click += new System.EventHandler(this.clienteFisicoToolStripMenuItem_Click);
            // 
            // atendimentoToolStripMenuItem
            // 
            this.atendimentoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.agendarPessoaFisicaToolStripMenuItem});
            this.atendimentoToolStripMenuItem.Name = "atendimentoToolStripMenuItem";
            this.atendimentoToolStripMenuItem.Size = new System.Drawing.Size(110, 24);
            this.atendimentoToolStripMenuItem.Text = "Atendimento";
            // 
            // agendarPessoaFisicaToolStripMenuItem
            // 
            this.agendarPessoaFisicaToolStripMenuItem.Name = "agendarPessoaFisicaToolStripMenuItem";
            this.agendarPessoaFisicaToolStripMenuItem.Size = new System.Drawing.Size(238, 26);
            this.agendarPessoaFisicaToolStripMenuItem.Text = "Agendar atendimento";
            this.agendarPessoaFisicaToolStripMenuItem.Click += new System.EventHandler(this.agendarPessoaFisicaToolStripMenuItem_Click);
            // 
            // protocoloToolStripMenuItem
            // 
            this.protocoloToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.abrirProtocoloToolStripMenuItem});
            this.protocoloToolStripMenuItem.Name = "protocoloToolStripMenuItem";
            this.protocoloToolStripMenuItem.Size = new System.Drawing.Size(88, 24);
            this.protocoloToolStripMenuItem.Text = "Protocolo";
            // 
            // abrirProtocoloToolStripMenuItem
            // 
            this.abrirProtocoloToolStripMenuItem.Name = "abrirProtocoloToolStripMenuItem";
            this.abrirProtocoloToolStripMenuItem.Size = new System.Drawing.Size(195, 26);
            this.abrirProtocoloToolStripMenuItem.Text = "Abrir protocolo";
            this.abrirProtocoloToolStripMenuItem.Click += new System.EventHandler(this.abrirProtocoloToolStripMenuItem_Click);
            // 
            // transaçõesToolStripMenuItem
            // 
            this.transaçõesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.abrirTransaçõesToolStripMenuItem,
            this.avaliarTransaçõesToolStripMenuItem});
            this.transaçõesToolStripMenuItem.Name = "transaçõesToolStripMenuItem";
            this.transaçõesToolStripMenuItem.Size = new System.Drawing.Size(95, 24);
            this.transaçõesToolStripMenuItem.Text = "Transações";
            // 
            // abrirTransaçõesToolStripMenuItem
            // 
            this.abrirTransaçõesToolStripMenuItem.Name = "abrirTransaçõesToolStripMenuItem";
            this.abrirTransaçõesToolStripMenuItem.Size = new System.Drawing.Size(212, 26);
            this.abrirTransaçõesToolStripMenuItem.Text = "Abrir transações";
            this.abrirTransaçõesToolStripMenuItem.Click += new System.EventHandler(this.abrirTransaçõesToolStripMenuItem_Click);
            // 
            // avaliarTransaçõesToolStripMenuItem
            // 
            this.avaliarTransaçõesToolStripMenuItem.Name = "avaliarTransaçõesToolStripMenuItem";
            this.avaliarTransaçõesToolStripMenuItem.Size = new System.Drawing.Size(212, 26);
            this.avaliarTransaçõesToolStripMenuItem.Text = "Avaliar transações";
            this.avaliarTransaçõesToolStripMenuItem.Click += new System.EventHandler(this.avaliarTransaçõesToolStripMenuItem_Click);
            // 
            // relatóriosToolStripMenuItem
            // 
            this.relatóriosToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.funcionáriosCadastradosToolStripMenuItem,
            this.clientesFisicosCadastradosToolStripMenuItem,
            this.clientesJuridicosCadastradosToolStripMenuItem,
            this.protocolosToolStripMenuItem,
            this.agendamentoDeAtendimentoDePessoasFisicasToolStripMenuItem,
            this.agendamentoFuturoDeAtendimentoDePessoasFisicasToolStripMenuItem,
            this.transaçõesDeClientesFisicasToolStripMenuItem,
            this.transaçãoDeClientesJuridicasToolStripMenuItem,
            this.transaçõesFisicasAprovadasToolStripMenuItem,
            this.transaçõesJuridicasAprovadasToolStripMenuItem,
            this.transaçõesFisicasReprovadasToolStripMenuItem,
            this.transaçõesJuridicasReprovadasToolStripMenuItem});
            this.relatóriosToolStripMenuItem.Name = "relatóriosToolStripMenuItem";
            this.relatóriosToolStripMenuItem.Size = new System.Drawing.Size(90, 24);
            this.relatóriosToolStripMenuItem.Text = "Relatórios";
            // 
            // funcionáriosCadastradosToolStripMenuItem
            // 
            this.funcionáriosCadastradosToolStripMenuItem.Name = "funcionáriosCadastradosToolStripMenuItem";
            this.funcionáriosCadastradosToolStripMenuItem.Size = new System.Drawing.Size(477, 26);
            this.funcionáriosCadastradosToolStripMenuItem.Text = "Funcionários cadastrados";
            this.funcionáriosCadastradosToolStripMenuItem.Click += new System.EventHandler(this.funcionáriosCadastradosToolStripMenuItem_Click);
            // 
            // clientesFisicosCadastradosToolStripMenuItem
            // 
            this.clientesFisicosCadastradosToolStripMenuItem.Name = "clientesFisicosCadastradosToolStripMenuItem";
            this.clientesFisicosCadastradosToolStripMenuItem.Size = new System.Drawing.Size(477, 26);
            this.clientesFisicosCadastradosToolStripMenuItem.Text = "Clientes fisicos cadastrados";
            this.clientesFisicosCadastradosToolStripMenuItem.Click += new System.EventHandler(this.clientesFisicosCadastradosToolStripMenuItem_Click);
            // 
            // clientesJuridicosCadastradosToolStripMenuItem
            // 
            this.clientesJuridicosCadastradosToolStripMenuItem.Name = "clientesJuridicosCadastradosToolStripMenuItem";
            this.clientesJuridicosCadastradosToolStripMenuItem.Size = new System.Drawing.Size(477, 26);
            this.clientesJuridicosCadastradosToolStripMenuItem.Text = "Clientes juridicos cadastrados";
            this.clientesJuridicosCadastradosToolStripMenuItem.Click += new System.EventHandler(this.clientesJuridicosCadastradosToolStripMenuItem_Click);
            // 
            // protocolosToolStripMenuItem
            // 
            this.protocolosToolStripMenuItem.Name = "protocolosToolStripMenuItem";
            this.protocolosToolStripMenuItem.Size = new System.Drawing.Size(477, 26);
            this.protocolosToolStripMenuItem.Text = "Protocolos";
            this.protocolosToolStripMenuItem.Click += new System.EventHandler(this.protocolosToolStripMenuItem_Click);
            // 
            // agendamentoDeAtendimentoDePessoasFisicasToolStripMenuItem
            // 
            this.agendamentoDeAtendimentoDePessoasFisicasToolStripMenuItem.Name = "agendamentoDeAtendimentoDePessoasFisicasToolStripMenuItem";
            this.agendamentoDeAtendimentoDePessoasFisicasToolStripMenuItem.Size = new System.Drawing.Size(477, 26);
            this.agendamentoDeAtendimentoDePessoasFisicasToolStripMenuItem.Text = "Agendamento futuro de atendimento de pessoas fisicas";
            this.agendamentoDeAtendimentoDePessoasFisicasToolStripMenuItem.Click += new System.EventHandler(this.agendamentoDeAtendimentoDePessoasFisicasToolStripMenuItem_Click);
            // 
            // agendamentoFuturoDeAtendimentoDePessoasFisicasToolStripMenuItem
            // 
            this.agendamentoFuturoDeAtendimentoDePessoasFisicasToolStripMenuItem.Name = "agendamentoFuturoDeAtendimentoDePessoasFisicasToolStripMenuItem";
            this.agendamentoFuturoDeAtendimentoDePessoasFisicasToolStripMenuItem.Size = new System.Drawing.Size(477, 26);
            this.agendamentoFuturoDeAtendimentoDePessoasFisicasToolStripMenuItem.Text = "Agendamento futuro de atendimento de pessoas juridicas";
            this.agendamentoFuturoDeAtendimentoDePessoasFisicasToolStripMenuItem.Click += new System.EventHandler(this.agendamentoFuturoDeAtendimentoDePessoasFisicasToolStripMenuItem_Click);
            // 
            // transaçõesDeClientesFisicasToolStripMenuItem
            // 
            this.transaçõesDeClientesFisicasToolStripMenuItem.Name = "transaçõesDeClientesFisicasToolStripMenuItem";
            this.transaçõesDeClientesFisicasToolStripMenuItem.Size = new System.Drawing.Size(477, 26);
            this.transaçõesDeClientesFisicasToolStripMenuItem.Text = "Transações de clientes fisicas";
            this.transaçõesDeClientesFisicasToolStripMenuItem.Click += new System.EventHandler(this.transaçõesDeClientesFisicasToolStripMenuItem_Click);
            // 
            // transaçãoDeClientesJuridicasToolStripMenuItem
            // 
            this.transaçãoDeClientesJuridicasToolStripMenuItem.Name = "transaçãoDeClientesJuridicasToolStripMenuItem";
            this.transaçãoDeClientesJuridicasToolStripMenuItem.Size = new System.Drawing.Size(477, 26);
            this.transaçãoDeClientesJuridicasToolStripMenuItem.Text = "Transações de clientes juridicas";
            this.transaçãoDeClientesJuridicasToolStripMenuItem.Click += new System.EventHandler(this.transaçãoDeClientesJuridicasToolStripMenuItem_Click);
            // 
            // transaçõesFisicasAprovadasToolStripMenuItem
            // 
            this.transaçõesFisicasAprovadasToolStripMenuItem.Name = "transaçõesFisicasAprovadasToolStripMenuItem";
            this.transaçõesFisicasAprovadasToolStripMenuItem.Size = new System.Drawing.Size(477, 26);
            this.transaçõesFisicasAprovadasToolStripMenuItem.Text = "Transações fisicas aprovadas";
            this.transaçõesFisicasAprovadasToolStripMenuItem.Click += new System.EventHandler(this.transaçõesFisicasAprovadasToolStripMenuItem_Click);
            // 
            // transaçõesJuridicasAprovadasToolStripMenuItem
            // 
            this.transaçõesJuridicasAprovadasToolStripMenuItem.Name = "transaçõesJuridicasAprovadasToolStripMenuItem";
            this.transaçõesJuridicasAprovadasToolStripMenuItem.Size = new System.Drawing.Size(477, 26);
            this.transaçõesJuridicasAprovadasToolStripMenuItem.Text = "Transações juridicas aprovadas";
            this.transaçõesJuridicasAprovadasToolStripMenuItem.Click += new System.EventHandler(this.transaçõesJuridicasAprovadasToolStripMenuItem_Click);
            // 
            // transaçõesFisicasReprovadasToolStripMenuItem
            // 
            this.transaçõesFisicasReprovadasToolStripMenuItem.Name = "transaçõesFisicasReprovadasToolStripMenuItem";
            this.transaçõesFisicasReprovadasToolStripMenuItem.Size = new System.Drawing.Size(477, 26);
            this.transaçõesFisicasReprovadasToolStripMenuItem.Text = "Transações fisicas reprovadas";
            this.transaçõesFisicasReprovadasToolStripMenuItem.Click += new System.EventHandler(this.transaçõesFisicasReprovadasToolStripMenuItem_Click);
            // 
            // transaçõesJuridicasReprovadasToolStripMenuItem
            // 
            this.transaçõesJuridicasReprovadasToolStripMenuItem.Name = "transaçõesJuridicasReprovadasToolStripMenuItem";
            this.transaçõesJuridicasReprovadasToolStripMenuItem.Size = new System.Drawing.Size(477, 26);
            this.transaçõesJuridicasReprovadasToolStripMenuItem.Text = "Transações juridicas reprovadas";
            this.transaçõesJuridicasReprovadasToolStripMenuItem.Click += new System.EventHandler(this.transaçõesJuridicasReprovadasToolStripMenuItem_Click);
            // 
            // sobreOSistemaToolStripMenuItem
            // 
            this.sobreOSistemaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.equipeDeDesenvolvimentoToolStripMenuItem});
            this.sobreOSistemaToolStripMenuItem.Name = "sobreOSistemaToolStripMenuItem";
            this.sobreOSistemaToolStripMenuItem.Size = new System.Drawing.Size(129, 24);
            this.sobreOSistemaToolStripMenuItem.Text = "Sobre o sistema";
            // 
            // equipeDeDesenvolvimentoToolStripMenuItem
            // 
            this.equipeDeDesenvolvimentoToolStripMenuItem.Name = "equipeDeDesenvolvimentoToolStripMenuItem";
            this.equipeDeDesenvolvimentoToolStripMenuItem.Size = new System.Drawing.Size(276, 26);
            this.equipeDeDesenvolvimentoToolStripMenuItem.Text = "Equipe de desenvolvimento";
            this.equipeDeDesenvolvimentoToolStripMenuItem.Click += new System.EventHandler(this.equipeDeDesenvolvimentoToolStripMenuItem_Click);
            // 
            // btnFinalizarVenda
            // 
            this.btnFinalizarVenda.BackColor = System.Drawing.Color.Lime;
            this.btnFinalizarVenda.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnFinalizarVenda.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnFinalizarVenda.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFinalizarVenda.ForeColor = System.Drawing.Color.White;
            this.btnFinalizarVenda.Location = new System.Drawing.Point(16, 48);
            this.btnFinalizarVenda.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnFinalizarVenda.Name = "btnFinalizarVenda";
            this.btnFinalizarVenda.Size = new System.Drawing.Size(297, 44);
            this.btnFinalizarVenda.TabIndex = 23;
            this.btnFinalizarVenda.Text = "Cadastrar funcionário";
            this.btnFinalizarVenda.UseVisualStyleBackColor = false;
            this.btnFinalizarVenda.Click += new System.EventHandler(this.btnFinalizarVenda_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Lime;
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(16, 113);
            this.button1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(297, 44);
            this.button1.TabIndex = 24;
            this.button1.Text = "Cadastrar cliente fisico";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Lime;
            this.button2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(16, 182);
            this.button2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(297, 44);
            this.button2.TabIndex = 25;
            this.button2.Text = "Cadastrar cliente juridico";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Lime;
            this.button3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.White;
            this.button3.Location = new System.Drawing.Point(737, 48);
            this.button3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(297, 44);
            this.button3.TabIndex = 26;
            this.button3.Text = "Agendar atendimento";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.Lime;
            this.button4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.Color.White;
            this.button4.Location = new System.Drawing.Point(737, 113);
            this.button4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(297, 44);
            this.button4.TabIndex = 27;
            this.button4.Text = "Abrir protocolo";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.Lime;
            this.button5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.ForeColor = System.Drawing.Color.White;
            this.button5.Location = new System.Drawing.Point(737, 182);
            this.button5.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(297, 44);
            this.button5.TabIndex = 28;
            this.button5.Text = "Abrir transaçoes";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // tblRelatorio
            // 
            this.tblRelatorio.AllowUserToAddRows = false;
            this.tblRelatorio.AllowUserToDeleteRows = false;
            this.tblRelatorio.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tblRelatorio.Location = new System.Drawing.Point(856, 263);
            this.tblRelatorio.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tblRelatorio.Name = "tblRelatorio";
            this.tblRelatorio.ReadOnly = true;
            this.tblRelatorio.RowHeadersWidth = 51;
            this.tblRelatorio.Size = new System.Drawing.Size(160, 78);
            this.tblRelatorio.TabIndex = 30;
            this.tblRelatorio.Visible = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::SysBlockchain.Properties.Resources.Screenshot_2020_11_27_174202;
            this.pictureBox2.Location = new System.Drawing.Point(363, 70);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(314, 368);
            this.pictureBox2.TabIndex = 31;
            this.pictureBox2.TabStop = false;
            // 
            // frmPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(1067, 554);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.tblRelatorio);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnFinalizarVenda);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "frmPrincipal";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Principal";
            this.Load += new System.EventHandler(this.frmPrincipal_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tblRelatorio)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem cadastrosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem funcionáriosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem clienteJuridicoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem clienteFisicoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem atendimentoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem agendarPessoaFisicaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem protocoloToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem abrirProtocoloToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem transaçõesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem abrirTransaçõesToolStripMenuItem;
        private System.Windows.Forms.Button btnFinalizarVenda;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.ToolStripMenuItem relatóriosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sobreOSistemaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem equipeDeDesenvolvimentoToolStripMenuItem;
        private System.Windows.Forms.DataGridView tblRelatorio;
        private System.Windows.Forms.ToolStripMenuItem funcionáriosCadastradosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem clientesFisicosCadastradosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem clientesJuridicosCadastradosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem protocolosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem agendamentoDeAtendimentoDePessoasFisicasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem agendamentoFuturoDeAtendimentoDePessoasFisicasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem transaçõesDeClientesFisicasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem transaçãoDeClientesJuridicasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem avaliarTransaçõesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem transaçõesFisicasAprovadasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem transaçõesJuridicasAprovadasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem transaçõesFisicasReprovadasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem transaçõesJuridicasReprovadasToolStripMenuItem;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}