﻿using Negocios;
using ObjetosTransferencia;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SysBlockchain
{
    public partial class frmClienteFisico : Form
    {
        public frmClienteFisico()
        {
            InitializeComponent();
        }

        public void limparCampos()
        {
            txtCpf.Text = "";
            txtEmail.Text = "";
            txtNome.Text = "";
            txtTelefone.Text = "";
        }

        private void btnNovo_Click(object sender, EventArgs e)
        {
            limparCampos();
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            ClienteFisico clienteFisicos = new ClienteFisico();
            clienteFisicos.cpf = txtCpf.Text;
            clienteFisicos.email = txtEmail.Text;
            clienteFisicos.nome = txtNome.Text;
            clienteFisicos.telefone = txtTelefone.Text;

            ClienteFisicoNegocios clienteFisicoNegocios = new ClienteFisicoNegocios();

            String retorno = clienteFisicoNegocios.Inserir(clienteFisicos);

    

            try
            {
                int idCliente = Convert.ToInt32(retorno);

                MessageBox.Show("Cliente cadastrado com sucesso. Código: " + idCliente.ToString());
                limparCampos();
                this.Close();

            }
            catch (Exception exception)
            {
                MessageBox.Show("Não foi possível adicionar. Detalhes: " + exception.Message + " ou " + retorno);
            }

        }
    }
    
}
