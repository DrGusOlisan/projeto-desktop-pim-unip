﻿using AcessoBancoDados;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SysBlockchain
{
    public partial class frmAnalisarTransacoes : Form
    {
        SqlConnection con;
        DataTable dtbl = new DataTable();
        DataTable dtb2 = new DataTable();
        AcessoDadosSqlServer acessoDadosSqlServer = new AcessoDadosSqlServer();
        public frmAnalisarTransacoes()
        {
            InitializeComponent();
            con = acessoDadosSqlServer.CriarConexao();
            geraTabelaOperacaoFisica();
            geraTabelaOperacaoJuridica();
        }

        public void geraTabelaOperacaoFisica()
        {
            dtbl.Clear();
            tblTransacaoFisica.DataSource = null;
            SqlDataAdapter sqlD = new SqlDataAdapter("SELECT * FROM VW_TRANSACAOFISICAAVALIACAO", con);
            sqlD.Fill(dtbl);
            tblTransacaoFisica.DataSource = dtbl;
            tblTransacaoFisica.Columns[0].Visible = false;


        }



        public void geraTabelaOperacaoJuridica()
        {
            dtb2.Clear();
            tblTransacaoJuridica.DataSource = null;
            SqlDataAdapter sqlD = new SqlDataAdapter("SELECT * FROM VW_TRANSACAOJURIDICAAVALIACAO", con);
            sqlD.Fill(dtb2);
            tblTransacaoJuridica.DataSource = dtb2;
            tblTransacaoJuridica.Columns[0].Visible = false;


        }

        private void tblTransacaoFisica_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            frmAvaliaFisico c = new frmAvaliaFisico(this, tblTransacaoFisica.CurrentRow.Cells[4].Value.ToString(), tblTransacaoFisica.CurrentRow.Cells[1].Value.ToString(), tblTransacaoFisica.CurrentRow.Cells[3].Value.ToString(), Convert.ToInt32(tblTransacaoFisica.CurrentRow.Cells[0].Value.ToString()));
            c.ShowDialog();
        }

        private void tblTransacaoJuridica_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            frmAvaliaJuridico c = new frmAvaliaJuridico(this, tblTransacaoJuridica.CurrentRow.Cells[4].Value.ToString(), tblTransacaoJuridica.CurrentRow.Cells[1].Value.ToString(), tblTransacaoJuridica.CurrentRow.Cells[3].Value.ToString(), Convert.ToInt32(tblTransacaoJuridica.CurrentRow.Cells[0].Value.ToString()));
            c.ShowDialog();
        }
    }
}
