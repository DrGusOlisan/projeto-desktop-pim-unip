﻿using Negocios;
using ObjetosTransferencia;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SysBlockchain
{
    public partial class frmFuncionario : Form
    {
        public frmFuncionario()
        {
            InitializeComponent();
        }

        public void limparCampos()
        {
            txtLogin.Text = "";
            txtNome.Text = "";
            txtSalario.Text = "";
            txtSenha.Text = "";
        }

        private void btnNovo_Click(object sender, EventArgs e)
        {
            limparCampos();
        }

        private void txtSalario_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != ','))
            {
                e.Handled = true;
                MessageBox.Show("este campo aceita somente numero e virgula");
            }
            if ((e.KeyChar == ',') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
                MessageBox.Show("este campo aceita somente uma virgula");
            }
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            Funcionario f = new Funcionario();
            f.salario = Convert.ToDecimal(txtSalario.Text);
            f.login = txtLogin.Text;
            f.senha = txtSenha.Text;
            f.nome = txtNome.Text;
            if (rdGerente.Checked)
            {
                f.gerente = '1';
            }
            else
            {
                f.gerente = '0';
            }
            FuncionarioNegocios funcionarioNegocios = new FuncionarioNegocios();


            String retorno = funcionarioNegocios.Inserir(f);

            try
            {
                int idColaborador = Convert.ToInt32(retorno);

                MessageBox.Show("Funcionario cadastrado com sucesso. Código: " + idColaborador.ToString());
                limparCampos();
                this.Close();

            }
            catch (Exception exception)
            {
                MessageBox.Show("Não foi possível adicionar. Detalhes: " + exception.Message + " ou " + retorno);
            }
        }

        private void txtSalario_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
