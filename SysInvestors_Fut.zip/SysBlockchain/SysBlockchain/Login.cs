﻿using AcessoBancoDados;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SysBlockchain
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
            txtLogin.Text = "Joao";
            txtSenha.Text = "123";
        }

        DataTable dtbl = new DataTable();
        AcessoDadosSqlServer acessoDadosSqlServer = new AcessoDadosSqlServer();

        private void label4_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int cod = acessoDadosSqlServer.verificaLogin(txtLogin.Text, txtSenha.Text);
            if (cod > 0)
            {
                this.Hide();
                Form f = new frmPrincipal(cod);
                f.Closed += (s, args) => this.Close();
                f.Show();
            }
            else
            {
                MessageBox.Show("Erro ao tentar acessar o sistema: " + "Parece que seu login ou senha estão incorretos", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
