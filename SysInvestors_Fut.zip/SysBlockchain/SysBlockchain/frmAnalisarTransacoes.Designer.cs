﻿namespace SysBlockchain
{
    partial class frmAnalisarTransacoes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tblTransacaoFisica = new System.Windows.Forms.DataGridView();
            this.label5 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.tblTransacaoJuridica = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tblTransacaoFisica)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tblTransacaoJuridica)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(35, 16);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(935, 434);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.tblTransacaoFisica);
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabPage1.Size = new System.Drawing.Size(927, 405);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Transações fisicas";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tblTransacaoFisica
            // 
            this.tblTransacaoFisica.AllowUserToAddRows = false;
            this.tblTransacaoFisica.AllowUserToDeleteRows = false;
            this.tblTransacaoFisica.AllowUserToOrderColumns = true;
            this.tblTransacaoFisica.AllowUserToResizeColumns = false;
            this.tblTransacaoFisica.AllowUserToResizeRows = false;
            this.tblTransacaoFisica.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.tblTransacaoFisica.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.tblTransacaoFisica.BackgroundColor = System.Drawing.Color.White;
            this.tblTransacaoFisica.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tblTransacaoFisica.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tblTransacaoFisica.EnableHeadersVisualStyles = false;
            this.tblTransacaoFisica.GridColor = System.Drawing.Color.White;
            this.tblTransacaoFisica.Location = new System.Drawing.Point(23, 43);
            this.tblTransacaoFisica.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tblTransacaoFisica.MultiSelect = false;
            this.tblTransacaoFisica.Name = "tblTransacaoFisica";
            this.tblTransacaoFisica.ReadOnly = true;
            this.tblTransacaoFisica.RowHeadersWidth = 51;
            this.tblTransacaoFisica.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.tblTransacaoFisica.ShowEditingIcon = false;
            this.tblTransacaoFisica.ShowRowErrors = false;
            this.tblTransacaoFisica.Size = new System.Drawing.Size(872, 347);
            this.tblTransacaoFisica.TabIndex = 31;
            this.tblTransacaoFisica.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.tblTransacaoFisica_CellDoubleClick);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(19, 11);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(254, 17);
            this.label5.TabIndex = 30;
            this.label5.Text = "Clique na transação que deseja avaliar";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.tblTransacaoJuridica);
            this.tabPage2.Controls.Add(this.label1);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Size = new System.Drawing.Size(927, 405);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Transações juridicas";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // tblTransacaoJuridica
            // 
            this.tblTransacaoJuridica.AllowUserToAddRows = false;
            this.tblTransacaoJuridica.AllowUserToDeleteRows = false;
            this.tblTransacaoJuridica.AllowUserToOrderColumns = true;
            this.tblTransacaoJuridica.AllowUserToResizeColumns = false;
            this.tblTransacaoJuridica.AllowUserToResizeRows = false;
            this.tblTransacaoJuridica.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.tblTransacaoJuridica.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.tblTransacaoJuridica.BackgroundColor = System.Drawing.Color.White;
            this.tblTransacaoJuridica.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tblTransacaoJuridica.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tblTransacaoJuridica.EnableHeadersVisualStyles = false;
            this.tblTransacaoJuridica.GridColor = System.Drawing.Color.White;
            this.tblTransacaoJuridica.Location = new System.Drawing.Point(28, 43);
            this.tblTransacaoJuridica.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tblTransacaoJuridica.MultiSelect = false;
            this.tblTransacaoJuridica.Name = "tblTransacaoJuridica";
            this.tblTransacaoJuridica.ReadOnly = true;
            this.tblTransacaoJuridica.RowHeadersWidth = 51;
            this.tblTransacaoJuridica.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.tblTransacaoJuridica.ShowEditingIcon = false;
            this.tblTransacaoJuridica.ShowRowErrors = false;
            this.tblTransacaoJuridica.Size = new System.Drawing.Size(872, 347);
            this.tblTransacaoJuridica.TabIndex = 33;
            this.tblTransacaoJuridica.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.tblTransacaoJuridica_CellDoubleClick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(24, 11);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(254, 17);
            this.label1.TabIndex = 32;
            this.label1.Text = "Clique na transação que deseja avaliar";
            // 
            // frmAnalisarTransacoes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Lime;
            this.ClientSize = new System.Drawing.Size(1001, 489);
            this.Controls.Add(this.tabControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "frmAnalisarTransacoes";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Analisar transacoes";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tblTransacaoFisica)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tblTransacaoJuridica)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.DataGridView tblTransacaoFisica;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DataGridView tblTransacaoJuridica;
        private System.Windows.Forms.Label label1;
    }
}