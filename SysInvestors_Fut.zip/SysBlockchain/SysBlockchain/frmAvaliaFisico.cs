﻿using Negocios;
using ObjetosTransferencia;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SysBlockchain
{
    public partial class frmAvaliaFisico : Form
    {
        frmAnalisarTransacoes frm;
        String cliente; String descricao; String valor;
        int codigo;
        public frmAvaliaFisico(frmAnalisarTransacoes frm,String cliente, String descricao, String valor, int codigo)
        {
            InitializeComponent();
            rdAprovado.Checked = true;
            this.frm = frm;
            this.cliente = cliente;
            this.descricao = descricao;
            this.valor = valor;
            this.codigo = codigo;
            txtCliente.Text = cliente;
            txtDescricao.Text = descricao;
            txtValor.Text = "R$ " + valor;
        }

        private void frmAvaliaFisico_FormClosed(object sender, FormClosedEventArgs e)
        {
            frm.geraTabelaOperacaoFisica();
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            const string message =
        "Tem certeza deste procedimento?";
            const string caption = "Confirmação";
            var result = MessageBox.Show(message, caption,
                                         MessageBoxButtons.YesNo,
                                         MessageBoxIcon.Question);

            // If the no button was pressed ...
            if (result == DialogResult.No)
            {
                // cancel the closure of the form.
                return;
            }
            else
            {
                TransacaoFisica transacaoFisica = new TransacaoFisica();
                transacaoFisica.codigoTransacaoFisica = codigo;
                if (rdAprovado.Checked)
                {
                    transacaoFisica.aprovado = 'S';
                }
                else
                {
                    transacaoFisica.aprovado = 'N';
                }
                TransacaoFisicaNegocios transacaoFisicaNegocios = new TransacaoFisicaNegocios();

                transacaoFisicaNegocios.avalia(transacaoFisica);
                this.Close();

            }
            }
    }
}
