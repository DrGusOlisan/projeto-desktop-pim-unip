﻿using Negocios;
using ObjetosTransferencia;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SysBlockchain
{
    public partial class frmProtocolo : Form
    {
        public int codColaborador;
        public frmProtocolo(int codColaborador)
        {
            InitializeComponent();
            this.codColaborador = codColaborador;
        }

        private void btnAgendarFisica_Click(object sender, EventArgs e)
        {
            Protocolo p = new Protocolo();
            p.descricao = txtDescricao.Text;
            p.codigoFuncionario = codColaborador;

            ProtocoloNegocios protocoloNegocios = new ProtocoloNegocios();


            String retorno = protocoloNegocios.Inserir(p);

            try
            {
                int idColaborador = Convert.ToInt32(retorno);

                MessageBox.Show("Protocolo aberto com sucesso. Código: " + idColaborador.ToString());
                this.Close();

            }
            catch (Exception exception)
            {
                MessageBox.Show("Não foi possível adicionar. Detalhes: " + exception.Message + " ou " + retorno);
            }

        }
    }
}
