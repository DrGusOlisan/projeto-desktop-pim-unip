﻿namespace SysBlockchain
{
    partial class frmTransacao
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.btnAgendarFisica = new System.Windows.Forms.Button();
            this.tblAgendamentoFisico = new System.Windows.Forms.DataGridView();
            this.label6 = new System.Windows.Forms.Label();
            this.txtValorFisico = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtDescricaoFisica = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.button1 = new System.Windows.Forms.Button();
            this.txtValorJuridico = new System.Windows.Forms.TextBox();
            this.txtDescricaoJuridico = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tblAgendamentoJuridico = new System.Windows.Forms.DataGridView();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tblAgendamentoFisico)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tblAgendamentoJuridico)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(12, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(697, 397);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.btnAgendarFisica);
            this.tabPage1.Controls.Add(this.tblAgendamentoFisico);
            this.tabPage1.Controls.Add(this.label6);
            this.tabPage1.Controls.Add(this.txtValorFisico);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.txtDescricaoFisica);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(689, 371);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Transação fisica";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // btnAgendarFisica
            // 
            this.btnAgendarFisica.BackColor = System.Drawing.Color.CadetBlue;
            this.btnAgendarFisica.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAgendarFisica.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAgendarFisica.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAgendarFisica.ForeColor = System.Drawing.Color.White;
            this.btnAgendarFisica.Location = new System.Drawing.Point(74, 206);
            this.btnAgendarFisica.Name = "btnAgendarFisica";
            this.btnAgendarFisica.Size = new System.Drawing.Size(106, 36);
            this.btnAgendarFisica.TabIndex = 23;
            this.btnAgendarFisica.Text = "Registrar";
            this.btnAgendarFisica.UseVisualStyleBackColor = false;
            this.btnAgendarFisica.Click += new System.EventHandler(this.btnAgendarFisica_Click);
            // 
            // tblAgendamentoFisico
            // 
            this.tblAgendamentoFisico.AllowUserToAddRows = false;
            this.tblAgendamentoFisico.AllowUserToDeleteRows = false;
            this.tblAgendamentoFisico.AllowUserToOrderColumns = true;
            this.tblAgendamentoFisico.AllowUserToResizeColumns = false;
            this.tblAgendamentoFisico.AllowUserToResizeRows = false;
            this.tblAgendamentoFisico.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.tblAgendamentoFisico.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.tblAgendamentoFisico.BackgroundColor = System.Drawing.Color.White;
            this.tblAgendamentoFisico.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tblAgendamentoFisico.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tblAgendamentoFisico.EnableHeadersVisualStyles = false;
            this.tblAgendamentoFisico.GridColor = System.Drawing.Color.White;
            this.tblAgendamentoFisico.Location = new System.Drawing.Point(269, 40);
            this.tblAgendamentoFisico.MultiSelect = false;
            this.tblAgendamentoFisico.Name = "tblAgendamentoFisico";
            this.tblAgendamentoFisico.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.tblAgendamentoFisico.ShowEditingIcon = false;
            this.tblAgendamentoFisico.ShowRowErrors = false;
            this.tblAgendamentoFisico.Size = new System.Drawing.Size(384, 282);
            this.tblAgendamentoFisico.TabIndex = 22;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(266, 14);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(225, 13);
            this.label6.TabIndex = 21;
            this.label6.Text = "Selecione o cliente que deseja abrir transação";
            // 
            // txtValorFisico
            // 
            this.txtValorFisico.Location = new System.Drawing.Point(9, 101);
            this.txtValorFisico.Name = "txtValorFisico";
            this.txtValorFisico.Size = new System.Drawing.Size(171, 20);
            this.txtValorFisico.TabIndex = 9;
            this.txtValorFisico.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox1_KeyPress);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 85);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(34, 13);
            this.label1.TabIndex = 8;
            this.label1.Text = "Valor:";
            // 
            // txtDescricaoFisica
            // 
            this.txtDescricaoFisica.Location = new System.Drawing.Point(9, 30);
            this.txtDescricaoFisica.Multiline = true;
            this.txtDescricaoFisica.Name = "txtDescricaoFisica";
            this.txtDescricaoFisica.Size = new System.Drawing.Size(218, 41);
            this.txtDescricaoFisica.TabIndex = 7;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 14);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(58, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Descrição:";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.label4);
            this.tabPage2.Controls.Add(this.tblAgendamentoJuridico);
            this.tabPage2.Controls.Add(this.label5);
            this.tabPage2.Controls.Add(this.button1);
            this.tabPage2.Controls.Add(this.txtValorJuridico);
            this.tabPage2.Controls.Add(this.txtDescricaoJuridico);
            this.tabPage2.Controls.Add(this.label3);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(689, 371);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Transação juridica";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.CadetBlue;
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(74, 206);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(106, 36);
            this.button1.TabIndex = 27;
            this.button1.Text = "Registrar";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // txtValorJuridico
            // 
            this.txtValorJuridico.Location = new System.Drawing.Point(9, 101);
            this.txtValorJuridico.Name = "txtValorJuridico";
            this.txtValorJuridico.Size = new System.Drawing.Size(171, 20);
            this.txtValorJuridico.TabIndex = 26;
            this.txtValorJuridico.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox2_KeyPress);
            // 
            // txtDescricaoJuridico
            // 
            this.txtDescricaoJuridico.Location = new System.Drawing.Point(9, 30);
            this.txtDescricaoJuridico.Multiline = true;
            this.txtDescricaoJuridico.Name = "txtDescricaoJuridico";
            this.txtDescricaoJuridico.Size = new System.Drawing.Size(218, 41);
            this.txtDescricaoJuridico.TabIndex = 25;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 14);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(58, 13);
            this.label3.TabIndex = 24;
            this.label3.Text = "Descrição:";
            // 
            // tblAgendamentoJuridico
            // 
            this.tblAgendamentoJuridico.AllowUserToAddRows = false;
            this.tblAgendamentoJuridico.AllowUserToDeleteRows = false;
            this.tblAgendamentoJuridico.AllowUserToOrderColumns = true;
            this.tblAgendamentoJuridico.AllowUserToResizeColumns = false;
            this.tblAgendamentoJuridico.AllowUserToResizeRows = false;
            this.tblAgendamentoJuridico.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.tblAgendamentoJuridico.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.tblAgendamentoJuridico.BackgroundColor = System.Drawing.Color.White;
            this.tblAgendamentoJuridico.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tblAgendamentoJuridico.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tblAgendamentoJuridico.EnableHeadersVisualStyles = false;
            this.tblAgendamentoJuridico.GridColor = System.Drawing.Color.White;
            this.tblAgendamentoJuridico.Location = new System.Drawing.Point(269, 40);
            this.tblAgendamentoJuridico.MultiSelect = false;
            this.tblAgendamentoJuridico.Name = "tblAgendamentoJuridico";
            this.tblAgendamentoJuridico.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.tblAgendamentoJuridico.ShowEditingIcon = false;
            this.tblAgendamentoJuridico.ShowRowErrors = false;
            this.tblAgendamentoJuridico.Size = new System.Drawing.Size(384, 282);
            this.tblAgendamentoJuridico.TabIndex = 29;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(266, 14);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(225, 13);
            this.label5.TabIndex = 28;
            this.label5.Text = "Selecione o cliente que deseja abrir transação";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 85);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(34, 13);
            this.label4.TabIndex = 30;
            this.label4.Text = "Valor:";
            // 
            // frmTransacao
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkCyan;
            this.ClientSize = new System.Drawing.Size(721, 421);
            this.Controls.Add(this.tabControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.Name = "frmTransacao";
            this.Text = "Cadastro de transações";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tblAgendamentoFisico)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tblAgendamentoJuridico)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TextBox txtDescricaoFisica;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtValorFisico;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView tblAgendamentoFisico;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnAgendarFisica;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox txtValorJuridico;
        private System.Windows.Forms.TextBox txtDescricaoJuridico;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DataGridView tblAgendamentoJuridico;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
    }
}