﻿using Negocios;
using ObjetosTransferencia;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SysBlockchain
{
    public partial class frmClienteJuridico : Form
    {
        public frmClienteJuridico()
        {
            InitializeComponent();
        }

        public void limparCampos()
        {
            txtCnpj.Text = "";
            txtEmail.Text = "";
            txtInscricaoEstadual.Text = "";
            txtRazaoSocial.Text = "";
            txtTelefone.Text = "";
        }

        private void btnNovo_Click(object sender, EventArgs e)
        {
            limparCampos();
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            ClienteJuridico clienteJuridico = new ClienteJuridico();
            clienteJuridico.cnpj = txtCnpj.Text;
            clienteJuridico.email = txtEmail.Text;
            clienteJuridico.inscricaoEstadual = txtInscricaoEstadual.Text;
            clienteJuridico.razaoSocial = txtRazaoSocial.Text;
            clienteJuridico.telefone = txtTelefone.Text;

            ClienteJuridicoNegocios clienteJuridicoNegocios = new ClienteJuridicoNegocios();


            String retorno = clienteJuridicoNegocios.Inserir(clienteJuridico);

            try
            {
                int idCliente = Convert.ToInt32(retorno);

                MessageBox.Show("Cliente cadastrado com sucesso. Código: " + idCliente.ToString());
                limparCampos();
                this.Close();

            }
            catch (Exception exception)
            {
                MessageBox.Show("Não foi possível adicionar. Detalhes: " + exception.Message + " ou " + retorno);
            }

        }
    }
}
