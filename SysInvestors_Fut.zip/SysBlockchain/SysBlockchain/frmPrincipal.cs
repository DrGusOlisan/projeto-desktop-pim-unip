﻿using AcessoBancoDados;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SysBlockchain
{
    public partial class frmPrincipal : Form
    {
        public int codColaborador;
        DataTable dtbl = new DataTable();
        SqlConnection con;
        AcessoDadosSqlServer acessoDadosSqlServer = new AcessoDadosSqlServer();
        public frmPrincipal(int codColaborador)
        {
            InitializeComponent();
            this.codColaborador = codColaborador;
            con = acessoDadosSqlServer.CriarConexao();
        }

        private void funcionáriosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmFuncionario c = new frmFuncionario();
            c.ShowDialog();
        }

        private void clienteJuridicoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmClienteJuridico c = new frmClienteJuridico();
            c.ShowDialog();
        }

        private void clienteFisicoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmClienteFisico c = new frmClienteFisico();
            c.ShowDialog();
        }

        private void agendarPessoaFisicaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmAgendar c = new frmAgendar();
            c.ShowDialog();
        }

        private void abrirProtocoloToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmProtocolo c = new frmProtocolo(codColaborador);
            c.ShowDialog();
        }

        private void abrirTransaçõesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmTransacao c = new frmTransacao(codColaborador);
            c.ShowDialog();
        }

        private void equipeDeDesenvolvimentoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmEquipeDesenvolvimento c = new frmEquipeDesenvolvimento();
            c.ShowDialog();
        }

        private void btnFinalizarVenda_Click(object sender, EventArgs e)
        {
            frmFuncionario c = new frmFuncionario();
            c.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            frmClienteFisico c = new frmClienteFisico();
            c.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            frmClienteJuridico c = new frmClienteJuridico();
            c.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            frmAgendar c = new frmAgendar();
            c.ShowDialog();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            frmProtocolo c = new frmProtocolo(codColaborador);
            c.ShowDialog();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            frmTransacao c = new frmTransacao(codColaborador);
            c.ShowDialog();
        }

        public void geraExcel(String sql)
        {
            dtbl.Clear(); // apaga as linhas
            int qtdColunas = dtbl.Rows.Count; // apaga as colunas

            while (dtbl.Columns.Count > qtdColunas)
            {
                dtbl.Columns.RemoveAt(qtdColunas);
            }

            SqlDataAdapter sqlD = new SqlDataAdapter(sql, con);
            sqlD.Fill(dtbl);

            tblRelatorio.DataSource = dtbl;


            if (tblRelatorio.Rows.Count > 0)
            {
                this.Cursor = Cursors.WaitCursor;

                Microsoft.Office.Interop.Excel.Application xcelApp = new Microsoft.Office.Interop.Excel.Application();
                xcelApp.Application.Workbooks.Add(Type.Missing);


                Microsoft.Office.Interop.Excel.Range formatRange = null;
                for (int i = 1; i < tblRelatorio.Columns.Count + 1; i++)
                {
                    formatRange = xcelApp.Cells[1, i];
                    formatRange.EntireRow.Font.Size = 12;
                    formatRange.EntireRow.Font.Bold = true;
                    formatRange.Interior.Color = System.Drawing.Color.FromArgb(((int)(((byte)(12)))), ((int)(((byte)(46)))), ((int)(((byte)(94)))));
                    ColorTranslator.ToOle(System.Drawing.Color.Blue);
                    formatRange.Font.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.White);
                    formatRange.BorderAround(Microsoft.Office.Interop.Excel.XlLineStyle.xlContinuous,
                    Microsoft.Office.Interop.Excel.XlBorderWeight.xlThin, Microsoft.Office.Interop.Excel.XlColorIndex.xlColorIndexAutomatic,
                    Microsoft.Office.Interop.Excel.XlColorIndex.xlColorIndexAutomatic);
                    //xcelApp.Cells[1, i].Font.Bold = true;
                    //xcelApp.Cells[1, i].Style.Font.Size = 12;
                    xcelApp.Cells[1, i] = tblRelatorio.Columns[i - 1].HeaderText;
                }


                /*formatRange = xcelApp.get_Range("a1","f1");
                formatRange.EntireRow.Font.Bold = true;
                formatRange.EntireRow.Font.Size = 12;
                formatRange.Interior.Color = System.Drawing.
                ColorTranslator.ToOle(System.Drawing.Color.Blue);
                formatRange.Font.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.White);
                formatRange.BorderAround(Microsoft.Office.Interop.Excel.XlLineStyle.xlContinuous,
                Microsoft.Office.Interop.Excel.XlBorderWeight.xlMedium, Microsoft.Office.Interop.Excel.XlColorIndex.xlColorIndexAutomatic,
                Microsoft.Office.Interop.Excel.XlColorIndex.xlColorIndexAutomatic);
                //xcelApp.Cells[1, 5] = "Bold";*/


                Microsoft.Office.Interop.Excel.Range formatRange2;
                for (int i = 0; i < tblRelatorio.Rows.Count; i++)
                {
                    for (int j = 0; j < tblRelatorio.Columns.Count; j++)
                    {
                        formatRange2 = xcelApp.Cells[i + 2, j + 1];
                        formatRange2.BorderAround(Microsoft.Office.Interop.Excel.XlLineStyle.xlContinuous,
                        Microsoft.Office.Interop.Excel.XlBorderWeight.xlThin, Microsoft.Office.Interop.Excel.XlColorIndex.xlColorIndexAutomatic,
                        Microsoft.Office.Interop.Excel.XlColorIndex.xlColorIndexAutomatic);

                        /*if (j == 3)
                        {

                            xcelApp.Cells[i + 2, j + 1] = Convert.ToDateTime(dataGridView.Rows[i].Cells[j].Value.ToString());
                            continue;
                        }*/
                        xcelApp.Cells[i + 2, j + 1] = tblRelatorio.Rows[i].Cells[j].Value.ToString();
                    }
                }
                xcelApp.Columns.AutoFit();
                xcelApp.Visible = true;
                this.Cursor = Cursors.Default;
            }
        }

        private void transaçõesJuridicasAprovadasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            geraExcel("SELECT * FROM VW_TRANSACAOJURIDICAAPROVADAS");
        }

        private void transaçõesFisicasAprovadasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            geraExcel("SELECT * FROM VW_TRANSACAOFISICAAPROVADAS");
        }

        private void funcionáriosCadastradosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            geraExcel("SELECT * FROM VW_FUNCIONARIOS");
        }

        private void clientesFisicosCadastradosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            geraExcel("SELECT * FROM VW_CLIENTESFISICOS");
        }

        private void clientesJuridicosCadastradosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            geraExcel("SELECT * FROM VW_CLIENTESJURIDICOS");
        }

        private void protocolosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            geraExcel("SELECT * FROM VW_PROTOCOLOS");
        }

        private void agendamentoDeAtendimentoDePessoasFisicasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            geraExcel("SELECT * FROM VW_AGENDAMENTOFISICO");
        }

        private void agendamentoFuturoDeAtendimentoDePessoasFisicasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            geraExcel("SELECT * FROM VW_AGENDAMENTOJURIDICO");
        }

        private void transaçõesDeClientesFisicasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            geraExcel("SELECT * FROM VW_TRANSACAOFISICA");
        }

        private void transaçãoDeClientesJuridicasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            geraExcel("SELECT * FROM VW_TRANSACAOJURIDICA");
        }

        private void avaliarTransaçõesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmAnalisarTransacoes c = new frmAnalisarTransacoes();
            c.ShowDialog();
        }

        private void transaçõesFisicasAprovToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
                geraExcel("SELECT * FROM VW_TRANSACAOFISICAAPROVADAS");
            
        }

        private void transaçõesFisicasReprovadasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            geraExcel("SELECT * FROM VW_TRANSACAOFISICAREPROVADAS");
        }

        private void transaçõesJuridicasReprovadasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            geraExcel("SELECT * FROM VW_TRANSACAOJURIDICAREPROVADAS");
            
        }

        private void frmPrincipal_Load(object sender, EventArgs e)
        {

        }
    }
}
