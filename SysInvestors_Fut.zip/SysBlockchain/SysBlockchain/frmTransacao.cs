﻿using AcessoBancoDados;
using Negocios;
using ObjetosTransferencia;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SysBlockchain
{
    public partial class frmTransacao : Form

    { 
        SqlConnection con;
    DataTable dtbl = new DataTable();
    DataTable dtb2 = new DataTable();
    AcessoDadosSqlServer acessoDadosSqlServer = new AcessoDadosSqlServer();
        int codFunc;
    public frmTransacao(int codigoFuncionario)
        {
            InitializeComponent();
        con = acessoDadosSqlServer.CriarConexao();
        geraTabelaClienteFisico();
        geraTabelaClienteJuridico();
           this.codFunc = codigoFuncionario;
    }

        public void geraTabelaClienteFisico()
        {
            dtb2.Clear();
            tblAgendamentoFisico.DataSource = null;
            SqlDataAdapter sqlD = new SqlDataAdapter(" SELECT NOME,CPF,CODIGOCLIENTEFISICO FROM CLIENTEFISICO", con);
            sqlD.Fill(dtb2);
            tblAgendamentoFisico.DataSource = dtb2;
            tblAgendamentoFisico.Columns[2].Visible = false;

        }

        public void geraTabelaClienteJuridico()
        {
            dtbl.Clear();
            tblAgendamentoJuridico.DataSource = null;
            SqlDataAdapter sqlD = new SqlDataAdapter("SELECT RAZAOSOCIAL,CNPJ,CODIGOCLIENTEJURIDICO FROM CLIENTEJURIDICO", con);
            sqlD.Fill(dtbl);
            tblAgendamentoJuridico.DataSource = dtbl;
            tblAgendamentoJuridico.Columns[2].Visible = false;

        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != ','))
            {
                e.Handled = true;
                MessageBox.Show("este campo aceita somente numero e virgula");
            }
            if ((e.KeyChar == ',') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
                MessageBox.Show("este campo aceita somente uma virgula");
            }
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != ','))
            {
                e.Handled = true;
                MessageBox.Show("este campo aceita somente numero e virgula");
            }
            if ((e.KeyChar == ',') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
                MessageBox.Show("este campo aceita somente uma virgula");
            }
        }

        private void btnAgendarFisica_Click(object sender, EventArgs e)
        {
            TransacaoFisica transacaoFisica = new TransacaoFisica();
            transacaoFisica.descricao = txtDescricaoFisica.Text;
            transacaoFisica.valorTransacao = Convert.ToDecimal(txtValorFisico.Text);
            transacaoFisica.codigoFuncionario = codFunc;
            transacaoFisica.codigoClienteFisico = Convert.ToInt32(tblAgendamentoFisico.CurrentRow.Cells[2].Value.ToString());

            TransacaoFisicaNegocios transacaoFisicaNegocios = new TransacaoFisicaNegocios();

            String retorno = transacaoFisicaNegocios.Inserir(transacaoFisica);



            try
            {
                int idCliente = Convert.ToInt32(retorno);

                MessageBox.Show("Transação cadastrada com sucesso. Código: " + idCliente.ToString());
                this.Close();

            }
            catch (Exception exception)
            {
                MessageBox.Show("Não foi possível adicionar. Detalhes: " + exception.Message + " ou " + retorno);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            TransacaoJuridica transacaoJuridica = new TransacaoJuridica();
            transacaoJuridica.descricao = txtDescricaoJuridico.Text;
            transacaoJuridica.valorTransacao = Convert.ToDecimal(txtValorJuridico.Text);
            transacaoJuridica.codigoFuncionario = codFunc;
            transacaoJuridica.codigoClienteJuridico = Convert.ToInt32(tblAgendamentoJuridico.CurrentRow.Cells[2].Value.ToString());

            TransacaoJuridicaNegocios transacaoJuridicaNegocios = new TransacaoJuridicaNegocios();

            String retorno = transacaoJuridicaNegocios.Inserir(transacaoJuridica);



            try
            {
                int idCliente = Convert.ToInt32(retorno);

                MessageBox.Show("Transação cadastrada com sucesso. Código: " + idCliente.ToString());
                this.Close();

            }
            catch (Exception exception)
            {
                MessageBox.Show("Não foi possível adicionar. Detalhes: " + exception.Message + " ou " + retorno);
            }
        }

     
    }
}
