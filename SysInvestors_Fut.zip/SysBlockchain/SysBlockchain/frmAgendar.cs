﻿using AcessoBancoDados;
using Negocios;
using ObjetosTransferencia;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SysBlockchain
{
    public partial class frmAgendar : Form
    {
        SqlConnection con;
        DataTable dtbl = new DataTable();
        DataTable dtb2 = new DataTable();
        AcessoDadosSqlServer acessoDadosSqlServer = new AcessoDadosSqlServer();
        public frmAgendar()
        {
            InitializeComponent();
            con = acessoDadosSqlServer.CriarConexao();
            geraTabelaClienteFisico();
            geraTabelaClienteJuridico();
        }

        public void geraTabelaClienteFisico()
        {
            dtb2.Clear();
            tblAgendamentoFisico.DataSource = null;
            SqlDataAdapter sqlD = new SqlDataAdapter(" SELECT NOME,CPF,CODIGOCLIENTEFISICO FROM CLIENTEFISICO", con);
            sqlD.Fill(dtb2);
            tblAgendamentoFisico.DataSource = dtb2;
            tblAgendamentoFisico.Columns[2].Visible = false;

        }

        public void geraTabelaClienteJuridico()
        {
            dtbl.Clear();
            tblAgendamentoJuridico.DataSource = null;
            SqlDataAdapter sqlD = new SqlDataAdapter("SELECT RAZAOSOCIAL,CNPJ,CODIGOCLIENTEJURIDICO FROM CLIENTEJURIDICO", con);
            sqlD.Fill(dtbl);
            tblAgendamentoJuridico.DataSource = dtbl;
            tblAgendamentoJuridico.Columns[2].Visible = false;

        }

        private void btnAgendarFisica_Click(object sender, EventArgs e)
        {
            AgendamentoFisico c = new AgendamentoFisico();
            c.descricao = txtDescricaoFisico.Text;
            c.codigoClienteFisico = Convert.ToInt32(tblAgendamentoFisico.CurrentRow.Cells[2].Value.ToString());
            c.dataAgendamento = Convert.ToDateTime(dataFisico.Text);

            AgendamentoFisicoNegocios agendamentoFisicoNegocios = new AgendamentoFisicoNegocios();

            String retorno = agendamentoFisicoNegocios.Inserir(c);



            try
            {
                int idCliente = Convert.ToInt32(retorno);

                MessageBox.Show("Agendamento cadastrado com sucesso. Código: " + idCliente.ToString());
                this.Close();

            }
            catch (Exception exception)
            {
                MessageBox.Show("Não foi possível adicionar. Detalhes: " + exception.Message + " ou " + retorno);
            }
        }

        private void btnAgendaJuridico_Click(object sender, EventArgs e)
        {
            if(Convert.ToInt32(tblAgendamentoJuridico.CurrentRow.Cells[2].Value.ToString()) == 0)
            {
                MessageBox.Show("Selecione um cliente na tabela");
                return;
            }
            AgendamentoJuridico c = new AgendamentoJuridico();
            c.descricao = txtDescricaoJuridico.Text;
            c.codigoClienteJuridico = Convert.ToInt32(tblAgendamentoJuridico.CurrentRow.Cells[2].Value.ToString());
            c.dataAgendamento = Convert.ToDateTime(dataJuridico.Text);

            AgendamentoJuridicoNegocios agendamentoJuridicoNegocios = new AgendamentoJuridicoNegocios();

            String retorno = agendamentoJuridicoNegocios.Inserir(c);



            try
            {
                int idCliente = Convert.ToInt32(retorno);

                MessageBox.Show("Agendamento cadastrado com sucesso. Código: " + idCliente.ToString());
                this.Close();

            }
            catch (Exception exception)
            {
                MessageBox.Show("Não foi possível adicionar. Detalhes: " + exception.Message + " ou " + retorno);
            }
        }
    }
}
