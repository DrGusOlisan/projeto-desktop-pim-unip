﻿namespace SysBlockchain
{
    partial class frmAgendar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tblAgendamentoFisico = new System.Windows.Forms.DataGridView();
            this.label6 = new System.Windows.Forms.Label();
            this.btnAgendarFisica = new System.Windows.Forms.Button();
            this.txtDescricaoFisico = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dataFisico = new System.Windows.Forms.DateTimePicker();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.tblAgendamentoJuridico = new System.Windows.Forms.DataGridView();
            this.label5 = new System.Windows.Forms.Label();
            this.btnAgendaJuridico = new System.Windows.Forms.Button();
            this.txtDescricaoJuridico = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.dataJuridico = new System.Windows.Forms.DateTimePicker();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tblAgendamentoFisico)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tblAgendamentoJuridico)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(16, 15);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(969, 474);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.tblAgendamentoFisico);
            this.tabPage1.Controls.Add(this.label6);
            this.tabPage1.Controls.Add(this.btnAgendarFisica);
            this.tabPage1.Controls.Add(this.txtDescricaoFisico);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.dataFisico);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabPage1.Size = new System.Drawing.Size(961, 445);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Cliente fisico";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tblAgendamentoFisico
            // 
            this.tblAgendamentoFisico.AllowUserToAddRows = false;
            this.tblAgendamentoFisico.AllowUserToDeleteRows = false;
            this.tblAgendamentoFisico.AllowUserToOrderColumns = true;
            this.tblAgendamentoFisico.AllowUserToResizeColumns = false;
            this.tblAgendamentoFisico.AllowUserToResizeRows = false;
            this.tblAgendamentoFisico.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.tblAgendamentoFisico.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.tblAgendamentoFisico.BackgroundColor = System.Drawing.Color.White;
            this.tblAgendamentoFisico.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tblAgendamentoFisico.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tblAgendamentoFisico.EnableHeadersVisualStyles = false;
            this.tblAgendamentoFisico.GridColor = System.Drawing.Color.White;
            this.tblAgendamentoFisico.Location = new System.Drawing.Point(419, 65);
            this.tblAgendamentoFisico.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tblAgendamentoFisico.MultiSelect = false;
            this.tblAgendamentoFisico.Name = "tblAgendamentoFisico";
            this.tblAgendamentoFisico.RowHeadersWidth = 51;
            this.tblAgendamentoFisico.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.tblAgendamentoFisico.ShowEditingIcon = false;
            this.tblAgendamentoFisico.ShowRowErrors = false;
            this.tblAgendamentoFisico.Size = new System.Drawing.Size(512, 347);
            this.tblAgendamentoFisico.TabIndex = 20;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(415, 33);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(344, 17);
            this.label6.TabIndex = 19;
            this.label6.Text = "Selecione o cliente que deseja agendar atendimento:";
            // 
            // btnAgendarFisica
            // 
            this.btnAgendarFisica.BackColor = System.Drawing.Color.Black;
            this.btnAgendarFisica.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAgendarFisica.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAgendarFisica.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAgendarFisica.ForeColor = System.Drawing.Color.White;
            this.btnAgendarFisica.Location = new System.Drawing.Point(79, 368);
            this.btnAgendarFisica.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnAgendarFisica.Name = "btnAgendarFisica";
            this.btnAgendarFisica.Size = new System.Drawing.Size(141, 44);
            this.btnAgendarFisica.TabIndex = 18;
            this.btnAgendarFisica.Text = "Agendar";
            this.btnAgendarFisica.UseVisualStyleBackColor = false;
            this.btnAgendarFisica.Click += new System.EventHandler(this.btnAgendarFisica_Click);
            // 
            // txtDescricaoFisico
            // 
            this.txtDescricaoFisico.Location = new System.Drawing.Point(29, 129);
            this.txtDescricaoFisico.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtDescricaoFisico.Name = "txtDescricaoFisico";
            this.txtDescricaoFisico.Size = new System.Drawing.Size(327, 22);
            this.txtDescricaoFisico.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(25, 110);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(75, 17);
            this.label2.TabIndex = 2;
            this.label2.Text = "Descrição:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(25, 33);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(153, 17);
            this.label1.TabIndex = 1;
            this.label1.Text = "Data do agendamento:";
            // 
            // dataFisico
            // 
            this.dataFisico.CustomFormat = "dd/MM/yyyy HH:mm tt";
            this.dataFisico.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dataFisico.Location = new System.Drawing.Point(29, 65);
            this.dataFisico.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dataFisico.Name = "dataFisico";
            this.dataFisico.Size = new System.Drawing.Size(327, 22);
            this.dataFisico.TabIndex = 0;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.tblAgendamentoJuridico);
            this.tabPage2.Controls.Add(this.label5);
            this.tabPage2.Controls.Add(this.btnAgendaJuridico);
            this.tabPage2.Controls.Add(this.txtDescricaoJuridico);
            this.tabPage2.Controls.Add(this.label3);
            this.tabPage2.Controls.Add(this.label4);
            this.tabPage2.Controls.Add(this.dataJuridico);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabPage2.Size = new System.Drawing.Size(961, 445);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Cliente juridico";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // tblAgendamentoJuridico
            // 
            this.tblAgendamentoJuridico.AllowUserToAddRows = false;
            this.tblAgendamentoJuridico.AllowUserToDeleteRows = false;
            this.tblAgendamentoJuridico.AllowUserToOrderColumns = true;
            this.tblAgendamentoJuridico.AllowUserToResizeColumns = false;
            this.tblAgendamentoJuridico.AllowUserToResizeRows = false;
            this.tblAgendamentoJuridico.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.tblAgendamentoJuridico.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.tblAgendamentoJuridico.BackgroundColor = System.Drawing.Color.White;
            this.tblAgendamentoJuridico.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tblAgendamentoJuridico.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tblAgendamentoJuridico.EnableHeadersVisualStyles = false;
            this.tblAgendamentoJuridico.GridColor = System.Drawing.Color.White;
            this.tblAgendamentoJuridico.Location = new System.Drawing.Point(419, 65);
            this.tblAgendamentoJuridico.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tblAgendamentoJuridico.MultiSelect = false;
            this.tblAgendamentoJuridico.Name = "tblAgendamentoJuridico";
            this.tblAgendamentoJuridico.RowHeadersWidth = 51;
            this.tblAgendamentoJuridico.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.tblAgendamentoJuridico.ShowEditingIcon = false;
            this.tblAgendamentoJuridico.ShowRowErrors = false;
            this.tblAgendamentoJuridico.Size = new System.Drawing.Size(512, 347);
            this.tblAgendamentoJuridico.TabIndex = 21;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(415, 33);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(344, 17);
            this.label5.TabIndex = 18;
            this.label5.Text = "Selecione o cliente que deseja agendar atendimento:";
            // 
            // btnAgendaJuridico
            // 
            this.btnAgendaJuridico.BackColor = System.Drawing.Color.CadetBlue;
            this.btnAgendaJuridico.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAgendaJuridico.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAgendaJuridico.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAgendaJuridico.ForeColor = System.Drawing.Color.White;
            this.btnAgendaJuridico.Location = new System.Drawing.Point(79, 368);
            this.btnAgendaJuridico.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnAgendaJuridico.Name = "btnAgendaJuridico";
            this.btnAgendaJuridico.Size = new System.Drawing.Size(141, 44);
            this.btnAgendaJuridico.TabIndex = 17;
            this.btnAgendaJuridico.Text = "Agendar";
            this.btnAgendaJuridico.UseVisualStyleBackColor = false;
            this.btnAgendaJuridico.Click += new System.EventHandler(this.btnAgendaJuridico_Click);
            // 
            // txtDescricaoJuridico
            // 
            this.txtDescricaoJuridico.Location = new System.Drawing.Point(29, 129);
            this.txtDescricaoJuridico.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtDescricaoJuridico.Name = "txtDescricaoJuridico";
            this.txtDescricaoJuridico.Size = new System.Drawing.Size(327, 22);
            this.txtDescricaoJuridico.TabIndex = 7;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(25, 110);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(75, 17);
            this.label3.TabIndex = 6;
            this.label3.Text = "Descrição:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(25, 33);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(153, 17);
            this.label4.TabIndex = 5;
            this.label4.Text = "Data do agendamento:";
            // 
            // dataJuridico
            // 
            this.dataJuridico.CustomFormat = "dd/MM/yyyy HH:mm tt";
            this.dataJuridico.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dataJuridico.Location = new System.Drawing.Point(29, 65);
            this.dataJuridico.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dataJuridico.Name = "dataJuridico";
            this.dataJuridico.Size = new System.Drawing.Size(327, 22);
            this.dataJuridico.TabIndex = 4;
            // 
            // frmAgendar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Lime;
            this.ClientSize = new System.Drawing.Size(1067, 508);
            this.Controls.Add(this.tabControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "frmAgendar";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Agendamento";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tblAgendamentoFisico)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tblAgendamentoJuridico)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker dataFisico;
        private System.Windows.Forms.TextBox txtDescricaoFisico;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtDescricaoJuridico;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DateTimePicker dataJuridico;
        private System.Windows.Forms.Button btnAgendaJuridico;
        private System.Windows.Forms.Button btnAgendarFisica;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DataGridView tblAgendamentoFisico;
        private System.Windows.Forms.DataGridView tblAgendamentoJuridico;
    }
}