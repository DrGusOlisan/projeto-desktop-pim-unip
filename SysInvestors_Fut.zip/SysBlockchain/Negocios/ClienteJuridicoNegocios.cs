﻿using AcessoBancoDados;
using ObjetosTransferencia;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Negocios
{
    public class ClienteJuridicoNegocios
    {
        AcessoDadosSqlServer acessoDadosSqlServer = new AcessoDadosSqlServer();

        public string Inserir(ClienteJuridico clienteJuridico)
        {
            try
            {
                acessoDadosSqlServer.LimparParametros();
                acessoDadosSqlServer.AdicionarParametros("@cnpj", clienteJuridico.cnpj);
                acessoDadosSqlServer.AdicionarParametros("@inscricaoEstadual", clienteJuridico.inscricaoEstadual);
                acessoDadosSqlServer.AdicionarParametros("@razaoSocial", clienteJuridico.razaoSocial);
                acessoDadosSqlServer.AdicionarParametros("@telefone", clienteJuridico.telefone);
                acessoDadosSqlServer.AdicionarParametros("@email", clienteJuridico.email);

                //retorna o id do novo cliente
                return (acessoDadosSqlServer.ExecutarManipulacao(System.Data.CommandType.StoredProcedure, "uspClienteJuridicoInserir")).ToString();
            }
            catch (Exception exception)
            {
                return exception.Message;
            }
        }

    }
}
