﻿using AcessoBancoDados;
using ObjetosTransferencia;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Negocios
{
    public class AgendamentoFisicoNegocios
    {


        AcessoDadosSqlServer acessoDadosSqlServer = new AcessoDadosSqlServer();
        public string Inserir(AgendamentoFisico agendamentoFisico)
        {
            try
            {
                acessoDadosSqlServer.LimparParametros();
                acessoDadosSqlServer.AdicionarParametros("@dataAgendamento", agendamentoFisico.dataAgendamento);
                acessoDadosSqlServer.AdicionarParametros("@descricao", agendamentoFisico.descricao);
                acessoDadosSqlServer.AdicionarParametros("@codigoClienteFisico", agendamentoFisico.codigoClienteFisico);
             


                //retorna o id do novo cliente
                return (acessoDadosSqlServer.ExecutarManipulacao(System.Data.CommandType.StoredProcedure, "uspAgendamentoFisicoInserir")).ToString();
            }
            catch (Exception exception)
            {
                return exception.Message;
            }
        }

    }
}
