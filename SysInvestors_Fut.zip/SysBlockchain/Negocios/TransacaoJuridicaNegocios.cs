﻿using AcessoBancoDados;
using ObjetosTransferencia;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Negocios
{
    public class TransacaoJuridicaNegocios
    {
        AcessoDadosSqlServer acessoDadosSqlServer = new AcessoDadosSqlServer();
        public string Inserir(TransacaoJuridica transacaoJuridica)
        {
            try
            {
                acessoDadosSqlServer.LimparParametros();
                acessoDadosSqlServer.AdicionarParametros("@descricao", transacaoJuridica.descricao);
                acessoDadosSqlServer.AdicionarParametros("@valorTransacao", transacaoJuridica.valorTransacao);
                acessoDadosSqlServer.AdicionarParametros("@codigoClienteJuridico", transacaoJuridica.codigoClienteJuridico);
                acessoDadosSqlServer.AdicionarParametros("@codigoFuncionario", transacaoJuridica.codigoFuncionario);


                //retorna o id do novo cliente
                return (acessoDadosSqlServer.ExecutarManipulacao(System.Data.CommandType.StoredProcedure, "uspTransacaoJuridicaInserir")).ToString();
            }
            catch (Exception exception)
            {
                return exception.Message;
            }
        }
        public void avalia(TransacaoJuridica transacaoJuridica)
        {
            try
            {
                acessoDadosSqlServer.LimparParametros();
                acessoDadosSqlServer.AdicionarParametros("@codigo", transacaoJuridica.codigoTransacaoJuridica);
                acessoDadosSqlServer.AdicionarParametros("@status", transacaoJuridica.aprovado);

                //retorna o id do novo cliente
                acessoDadosSqlServer.ExecutarManipulacao(System.Data.CommandType.StoredProcedure, "uspTransacaoJuridicaAvalia");
                MessageBox.Show("Avaliação concluida !!!");
            }
            catch (Exception exception)
            {
                MessageBox.Show(exception.Message); ;
            }
        }
    }
}
