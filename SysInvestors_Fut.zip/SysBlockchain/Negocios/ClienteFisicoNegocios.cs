﻿using AcessoBancoDados;
using ObjetosTransferencia;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Negocios
{
    public class ClienteFisicoNegocios
    {
        AcessoDadosSqlServer acessoDadosSqlServer = new AcessoDadosSqlServer();
        public string Inserir(ClienteFisico clienteFisico)
        {
            try
            {
                acessoDadosSqlServer.LimparParametros();
                acessoDadosSqlServer.AdicionarParametros("@nome", clienteFisico.nome);
                acessoDadosSqlServer.AdicionarParametros("@email", clienteFisico.email);
                acessoDadosSqlServer.AdicionarParametros("@cpf", clienteFisico.cpf);
                acessoDadosSqlServer.AdicionarParametros("@telefone", clienteFisico.telefone);
                

                //retorna o id do novo cliente
                return (acessoDadosSqlServer.ExecutarManipulacao(System.Data.CommandType.StoredProcedure, "uspClienteFisicoInserir")).ToString();
            }
            catch (Exception exception)
            {
                return exception.Message;
            }
        }


    }
}
