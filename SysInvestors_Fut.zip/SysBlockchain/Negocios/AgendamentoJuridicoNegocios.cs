﻿using AcessoBancoDados;
using ObjetosTransferencia;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Negocios
{
    public class AgendamentoJuridicoNegocios
    {
        AcessoDadosSqlServer acessoDadosSqlServer = new AcessoDadosSqlServer();
        public string Inserir(AgendamentoJuridico agendamentoJuridico)
        {
            try
            {
                acessoDadosSqlServer.LimparParametros();
                acessoDadosSqlServer.AdicionarParametros("@dataAgendamento", agendamentoJuridico.dataAgendamento);
                acessoDadosSqlServer.AdicionarParametros("@descricao", agendamentoJuridico.descricao);
                acessoDadosSqlServer.AdicionarParametros("@codigoClienteJuridico", agendamentoJuridico.codigoClienteJuridico);



                //retorna o id do novo cliente
                return (acessoDadosSqlServer.ExecutarManipulacao(System.Data.CommandType.StoredProcedure, "uspAgendamentoJuridicoInserir")).ToString();
            }
            catch (Exception exception)
            {
                return exception.Message;
            }
        }
    }
}
