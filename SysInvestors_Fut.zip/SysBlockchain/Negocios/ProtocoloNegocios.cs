﻿using AcessoBancoDados;
using ObjetosTransferencia;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Negocios
{
    public class ProtocoloNegocios
    {
        AcessoDadosSqlServer acessoDadosSqlServer = new AcessoDadosSqlServer();
        public string Inserir(Protocolo protocolo)
        {
            try
            {
                acessoDadosSqlServer.LimparParametros();
                acessoDadosSqlServer.AdicionarParametros("@descricao", protocolo.descricao);
                acessoDadosSqlServer.AdicionarParametros("@codigoFuncionario", protocolo.codigoFuncionario);

                //retorna o id do novo cliente
                return (acessoDadosSqlServer.ExecutarManipulacao(System.Data.CommandType.StoredProcedure, "uspProtocoloInserir")).ToString();
            }
            catch (Exception exception)
            {
                return exception.Message;
            }
        }
    }
}
