﻿using AcessoBancoDados;
using ObjetosTransferencia;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Negocios
{
    public class TransacaoFisicaNegocios
    {
        AcessoDadosSqlServer acessoDadosSqlServer = new AcessoDadosSqlServer();
        public string Inserir(TransacaoFisica transacaoFisica)
        {
            try
            {
                acessoDadosSqlServer.LimparParametros();
                acessoDadosSqlServer.AdicionarParametros("@descricao", transacaoFisica.descricao);
                acessoDadosSqlServer.AdicionarParametros("@valorTransacao", transacaoFisica.valorTransacao);
                acessoDadosSqlServer.AdicionarParametros("@codigoClienteFisico", transacaoFisica.codigoClienteFisico);
                acessoDadosSqlServer.AdicionarParametros("@codigoFuncionario", transacaoFisica.codigoFuncionario);



                //retorna o id do novo cliente
                return (acessoDadosSqlServer.ExecutarManipulacao(System.Data.CommandType.StoredProcedure, "uspTransacaoFisicaInserir")).ToString();
            }
            catch (Exception exception)
            {
                return exception.Message;
            }
        }

        public void avalia(TransacaoFisica transacaoFisica)
        {
            try
            {
                acessoDadosSqlServer.LimparParametros();
                acessoDadosSqlServer.AdicionarParametros("@codigo", transacaoFisica.codigoTransacaoFisica);
                acessoDadosSqlServer.AdicionarParametros("@status", transacaoFisica.aprovado);

                //retorna o id do novo cliente
               acessoDadosSqlServer.ExecutarManipulacao(System.Data.CommandType.StoredProcedure, "uspTransacaoFisicaAvalia");
                MessageBox.Show("Avaliação concluida !!!");
            }
            catch (Exception exception)
            {
                MessageBox.Show(exception.Message); ;
            }
        }

    }
}
