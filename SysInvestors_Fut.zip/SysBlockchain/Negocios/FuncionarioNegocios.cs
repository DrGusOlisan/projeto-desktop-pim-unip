﻿using AcessoBancoDados;
using ObjetosTransferencia;
using System;

namespace Negocios
{
    public class FuncionarioNegocios
    {

        AcessoDadosSqlServer acessoDadosSqlServer = new AcessoDadosSqlServer();


        public string Inserir(Funcionario funcionario)
        {
            try
            {
                acessoDadosSqlServer.LimparParametros();
                acessoDadosSqlServer.AdicionarParametros("@salario", funcionario.salario);
                acessoDadosSqlServer.AdicionarParametros("@login", funcionario.login);
                acessoDadosSqlServer.AdicionarParametros("@senha", funcionario.senha);
                acessoDadosSqlServer.AdicionarParametros("@nome", funcionario.nome);
                acessoDadosSqlServer.AdicionarParametros("@gerente", funcionario.gerente);

                //retorna o id do novo cliente
                return (acessoDadosSqlServer.ExecutarManipulacao(System.Data.CommandType.StoredProcedure, "uspFuncionarioInserir")).ToString();
            }
            catch (Exception exception)
            {
                return exception.Message;
            }
        }
    }
}
