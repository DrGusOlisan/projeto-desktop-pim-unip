﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObjetosTransferencia
{
    public class AgendamentoFisico
    {
        public int codigoAgendamentoFisico { get; set; }
        public DateTime dataCadastro { get; set; }
        public DateTime dataAgendamento { get; set; }
        public string descricao { get; set; }
        public int codigoClienteFisico { get; set; }

    }
}
