﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObjetosTransferencia
{
    public class TransacaoFisica
    {
        public int codigoTransacaoFisica { get; set; }
        public string  descricao { get; set; }
        public DateTime dataSolicitacao { get; set; }
        public char aprovado { get; set; }
        public decimal valorTransacao { get; set; }
        public int codigoClienteFisico { get; set; }
        public int codigoFuncionario { get; set; }
    }
}
