﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObjetosTransferencia
{
    public class ClienteFisico
    {
        public int codigoClienteFisico { get; set; }
        public string nome { get; set; }
        public string email { get; set; }
        public DateTime dataCadastro { get; set; }
        public string cpf { get; set; }
        public string telefone { get; set; }
    }
}
