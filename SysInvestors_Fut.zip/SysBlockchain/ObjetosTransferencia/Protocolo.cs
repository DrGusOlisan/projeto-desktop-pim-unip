﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObjetosTransferencia
{
    public class Protocolo
    {
        public int codigoProtocolo { get; set; }
        public string descricao { get; set; }
        public DateTime dataCadastro { get; set; }
        public int codigoFuncionario { get; set; }
        public char finalizado { get; set; }
    }
}
