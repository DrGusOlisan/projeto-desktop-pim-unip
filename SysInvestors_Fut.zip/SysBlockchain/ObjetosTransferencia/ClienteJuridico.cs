﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObjetosTransferencia
{
    public class ClienteJuridico
    {
        public int codigoClienteJuridico { get; set; }
        public string cnpj { get; set; }
        public string inscricaoEstadual { get; set; }
        public string razaoSocial { get; set; }
        public DateTime dataCadastro { get; set; }
        public string email { get; set; }
        public string telefone { get; set; }
    }
}
