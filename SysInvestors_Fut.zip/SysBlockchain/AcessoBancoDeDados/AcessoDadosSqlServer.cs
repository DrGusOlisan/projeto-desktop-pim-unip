﻿
using AcessoBancoDeDados.Properties;
using System;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace AcessoBancoDados
{
    public class AcessoDadosSqlServer
    {
        public bool tem = false;
        public int codigoColaborador{ get; set; }
        //Cria a conexão
        public SqlConnection CriarConexao()
        {
            return new SqlConnection(Settings.Default.StringConexao);

        }

        //Parâmetros que vão para o banco
        private SqlParameterCollection sqlParameterCollection = new SqlCommand().Parameters;


        public void LimparParametros()
        {
            sqlParameterCollection.Clear();
        }

        public void AdicionarParametros(string nomeParametro, object valorParametro)
        {
            sqlParameterCollection.Add(new SqlParameter(nomeParametro, valorParametro));
        }

        //Inserir,Alterar,Excluir
        public object ExecutarManipulacao(CommandType commandType, string nomeStoredProcedureOuTextoSql)
        {
            try
            {
                //Cria a conexao;
                SqlConnection sqlConnection = CriarConexao();
                //abrir a conexao
                sqlConnection.Open();
                //Cria o comando que vai levar a informação ao banco.
                SqlCommand sqlCommand = sqlConnection.CreateCommand();
                //colocando as coisas dentro do comando (dentro da caixa que vai trafegar a conexao)
                sqlCommand.CommandType = commandType;
                sqlCommand.CommandText = nomeStoredProcedureOuTextoSql;
                sqlCommand.CommandTimeout = 7000;


                //adiciona os parâmetros no comando
                foreach (SqlParameter sqlParameter in sqlParameterCollection)
                {
                    sqlCommand.Parameters.Add(new SqlParameter(sqlParameter.ParameterName, sqlParameter.Value));
                }

                //executa o comando, ou seja, manda o comando ir até o banco de dados
                return sqlCommand.ExecuteScalar();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        //consultar registros
        public DataTable ExecutarConsulta(CommandType commandType, string nomeStoredProcedureOuTextoSql)
        {
            try
            {


                //Cria a conexao;
                SqlConnection sqlConnection = CriarConexao();
                //abrir a conexao
                sqlConnection.Open();
                //Cria o comando que vai levar a informação ao banco.
                SqlCommand sqlCommand = sqlConnection.CreateCommand();
                //colocando as coisas dentro do comando (dentro da caixa que vai trafegar a conexao)
                sqlCommand.CommandType = commandType;
                sqlCommand.CommandText = nomeStoredProcedureOuTextoSql;
                sqlCommand.CommandTimeout = 7000;


                //adiciona os parâmetros no comando
                foreach (SqlParameter sqlParameter in sqlParameterCollection)
                {
                    sqlCommand.Parameters.Add(new SqlParameter(sqlParameter.ParameterName, sqlParameter.Value));
                }

                //executa o comando, ou seja, manda o comando ir até o banco de dados

                // cria um adaptador
                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlCommand);

                //Tabela de dados que vai receber os dados que vem do banco
                DataTable dataTable = new DataTable();

                //manda o comando ir até o banco buscar os dados e o adaptador preencher o datatable
                sqlDataAdapter.Fill(dataTable);

                return dataTable;

            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        public DataTable ObterTabela(DbDataReader reader)
        {
            DataTable tbEsquema = reader.GetSchemaTable();
            DataTable tbRetorno = new DataTable();

            foreach (DataRow r in tbEsquema.Rows)
            {
                if (!tbRetorno.Columns.Contains(r["ColumnName"].ToString()))
                {
                    DataColumn col = new DataColumn()
                    {
                        ColumnName = r["ColumnName"].ToString(),
                        Unique = Convert.ToBoolean(r["IsUnique"]),
                        AllowDBNull = Convert.ToBoolean(r["AllowDBNull"]),
                        ReadOnly = Convert.ToBoolean(r["IsReadOnly"])
                    };
                    tbRetorno.Columns.Add(col);
                }
            }

            while (reader.Read())
            {
                DataRow novaLinha = tbRetorno.NewRow();
                for (int i = 0; i < tbRetorno.Columns.Count; i++)
                {
                    novaLinha[i] = reader.GetValue(i);
                }
                tbRetorno.Rows.Add(novaLinha);
            }

            return tbRetorno;
        }

        public int verificaLogin(String usuario, String senha)
        {
            SqlCommand cmd = new SqlCommand();
            SqlConnection sqlConnection = CriarConexao();
            sqlConnection.Open();
            SqlDataReader dr;
            cmd.CommandText = "SELECT * FROM FUNCIONARIO WHERE LOGIN = @usuario AND rtrim(ltrim(SENHA)) = @senha";
            cmd.Parameters.AddWithValue("@usuario", usuario);
            cmd.Parameters.AddWithValue("@senha", senha);
            try
            {

                cmd.Connection = sqlConnection;

                if (cmd.Connection == null)
                {

                }
                dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    tem = true;

                    DataTable dataTable = ObterTabela(dr);

                    codigoColaborador = Convert.ToInt32(dataTable.Rows[0]["CODIGOFUNCIONARIO"].ToString());
                    /*Program.nomeUsuario = Convert.ToString(dataTable.Rows[0]["NOME"].ToString());*/
                    return codigoColaborador;
                }
                dr.Close();
                cmd.Parameters.Clear();
                cmd.Dispose();
            }
            catch (SqlException e)
            {
                MessageBox.Show("Erro ao tentar acessar o sistema: " + e.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return 0;
            }
            //  MessageBox.Show("resultado: " + tem, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return 0;
        }

    }
}
